module.exports = require('./webpack.config-helper')({
  isProduction: true,
  devtool: 'source-map'
});