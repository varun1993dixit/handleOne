const stringify = (obj) => {
    return JSON.stringify(obj);
};

export default stringify; 