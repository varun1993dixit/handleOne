const image =  (image) => {
    return require(`../assets/images/${ image }`);
};

export default image;