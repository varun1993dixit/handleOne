import customSelect from 'custom-select';
customSelect(document.getElementsByClassName('mySelect'));