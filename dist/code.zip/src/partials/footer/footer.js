if(document.getElementsByClassName('sidebar').length){
    document.getElementsByClassName('footer')[0].classList.add("footer--sub");
}
else{
    document.getElementsByClassName('footer')[0].classList.remove("footer--sub");
}